# Design System Specification: The Culinary Editorial

## 1. Overview & Creative North Star
**Creative North Star: "The Digital Curator"**
This design system moves beyond the utility of a standard recipe app to become a premium, high-end travel and food magazine. The experience is defined by **intentional asymmetry**, **cinematic photography**, and **tonal depth**. 

We reject the "boxed-in" template look. Instead, we use a sophisticated layering of warm surfaces to create a tactile, paper-like quality. By breaking the grid with overlapping elements and dramatic typography scales, we evoke the feeling of a physical coffee-table book where every page is a curated discovery.

---

## 2. Colors & Surface Philosophy
The palette is rooted in organic, earth-toned warmth. We use color not just for branding, but to signal hierarchy and emotional resonance.

### Color Tokens (Material Design Convention)
| Token | Light Mode | Dark Mode | Role |
| :--- | :--- | :--- | :--- |
| `primary` | #9A4100 | #FFB690 | Active CTAs, Branded Accents |
| `on-primary` | #FFFFFF | #341100 | Text/Icons on Primary |
| `surface` | #FEF9F3 | #0D0D0D | Main App Background |
| `surface-container-low` | #F8F3ED | #161B22 | Secondary sectioning |
| `surface-container-high`| #ECE7E2 | #252A32 | Cards and elevated sheets |
| `secondary` | #725A3C | #E1C19C | Metadata and subtle labels |
| `outline-variant` | #DEC1B3 | #32302C | "Ghost Borders" (use at 20% opacity) |

### The "No-Line" Rule
**Explicit Instruction:** Prohibit the use of 1px solid borders for sectioning or card definition. Boundaries must be defined solely through background color shifts. 
*   *Example:* A `surface-container-highest` card sitting on a `surface` background provides enough contrast to define a boundary without "cutting" the layout with a hard line.

### Glassmorphism & Texture
For floating elements (like a "Back" button over a recipe image), use **Glassmorphism**:
*   **Fill:** `surface` at 70% opacity.
*   **Blur:** 20px Backdrop Blur.
*   **Edge:** A 0.5pt stroke using `outline-variant` at 15% opacity to catch "specular" light.

---

## 3. Typography: The Editorial Voice
We utilize a high-contrast pairing of a functional Sans (Inter/SF Pro) and a romantic Serif (Noto Serif/Playfair Display) to mirror premium print journalism.

| Level | Token | Font | Size | Weight | Intent |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Display** | `display-lg` | Noto Serif | 3.5rem | Semi-Bold | Hero Recipe Titles |
| **Headline**| `headline-md`| Noto Serif | 1.75rem| Semi-Bold | Section Headers / Quotes |
| **Title** | `title-md` | Inter | 1.125rem| Semi-Bold | Card Titles / Sub-headers |
| **Body** | `body-lg` | Inter | 1.0rem | Regular | Recipe Instructions / Descriptions |
| **Label** | `label-md` | Inter | 0.75rem | Medium | Metadata Chips / Captions |

**Editorial Spacing:** Tighten tracking on `display` styles (-0.02em) to give a "custom-set" appearance. Increase line-height for `body-lg` to 1.6 to ensure a relaxed, aspirational reading pace.

---

## 4. Elevation & Depth: Tonal Layering
Traditional drop shadows are too "digital." We achieve depth through a physical stacking principle.

*   **The Layering Principle:** Treat the UI as layers of fine paper. A `surface-container-low` base may host a `surface-container-highest` card. This creates a soft, natural "lift" through value contrast rather than shadow.
*   **Ambient Shadows:** If a card must float (e.g., a bottom sheet), use an "Ambient Shadow": 
    *   *X: 0, Y: 12, Blur: 40, Spread: 0.*
    *   *Color:* Use `on-surface` at 6% opacity. This mimics natural light diffusion.
*   **The "Ghost Border":** For interactive inputs, use `outline-variant` at 10% opacity. It should be felt, not seen.

---

## 5. Components

### Buttons & Interaction
*   **Primary CTA:** `primary` fill, `on-primary` text. Height: 48pt. Radius: `xl` (1.5rem). Use a subtle linear gradient (Top: #C75B12 to Bottom: #9A4100) to add "soul."
*   **Secondary Action:** `secondary-container` fill with `on-secondary-container` text. Use for "Add to Grocery List."
*   **Serving Stepper:** A unified `surface-container-high` pill. The +/- icons should be `primary` to encourage interaction.

### Cards & Content
*   **The Magazine Card:** 12pt radius (`lg`). Images should use a 4:5 aspect ratio (vertical) or 16:9 (horizontal). 
*   **Overlays:** Use a "Linear Scrim" (Transparent to #000000 at 40% opacity) on the bottom 30% of images to ensure `white` text legibility.
*   **Dividers:** Forbidden. Use `spacing-8` (2.75rem) of vertical whitespace to separate sections.

### Immersive Components
*   **Cultural Quote Block:** A `headline-sm` serif text, italicized, centered, with a `primary` color flourish (like a large opening quotation mark).
*   **Ingredient Checkbox:** Custom circular toggle. Unchecked: `outline-variant` (20% opacity). Checked: `primary` fill with a white checkmark. The text should transition to `on-surface-variant` with a strikethrough when checked.

---

## 6. Do’s and Don’ts

### Do
*   **DO** use "bleed" layouts. Let high-quality food photography run edge-to-edge at the top of recipe screens.
*   **DO** embrace white space. If a layout feels "full," double the padding using the `spacing-12` or `spacing-16` tokens.
*   **DO** use Tonal Transitions. Move from `surface` to `surface-container-low` for different content chapters (e.g., from "The Story" to "The Ingredients").

### Don’t
*   **DON'T** use 100% black in light mode. Stick to `on-surface` (#1D1B18) to maintain the warm, organic feel.
*   **DON'T** use standard iOS blue for links. Everything interactive must be `primary` (Terracotta).
*   **DON'T** crowd the bottom tab bar. Use `label-sm` for clarity but ensure the `primary` active state is distinct through a subtle `primary-container` background pill behind the icon.

---

## 7. Spacing Scale
| Token | Value | Use Case |
| :--- | :--- | :--- |
| `spacing-3` | 1.0rem | Internal card padding |
| `spacing-6` | 2.0rem | Standard gutter / Page margins |
| `spacing-10` | 3.5rem | Vertical separation between distinct sections |
| `spacing-20` | 7.0rem | Large editorial breathing room (Hero to Body) |